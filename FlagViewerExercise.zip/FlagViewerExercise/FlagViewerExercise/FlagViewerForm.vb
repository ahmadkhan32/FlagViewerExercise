﻿Public Class FlagViewerForm
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub MalaysiaRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles MalaysiaRadioButton.CheckedChanged
        flagPictureBox.Image = MalaysiaPictureBox.Image
        countryLabel.Text = "Malaysia"
    End Sub

    Private Sub UKRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles UKRadioButton.CheckedChanged
        flagPictureBox.Image = UKPictureBox.Image
        countryLabel.Text = "United Kingdom"

    End Sub

    Private Sub JapanRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles JapanRadioButton.CheckedChanged
        flagPictureBox.Image = JapanPictureBox.Image
        countryLabel.Text = "Japan"
    End Sub

    Private Sub IndonesiaRadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles IndonesiaRadioButton.CheckedChanged
        flagPictureBox.Image = IndonesiaPictureBox.Image
        countryLabel.Text = "Indonesia"
    End Sub

    Private Sub TitleCheckBox_CheckedChanged(sender As Object, e As EventArgs) Handles TitleCheckBox.CheckedChanged
        titleLabel.Visible = TitleCheckBox.Checked

    End Sub

    Private Sub CountryCheckBox_CheckedChanged(sender As Object, e As EventArgs) Handles CountryCheckBox.CheckedChanged
        countryLabel.Visible = CountryCheckBox.Checked
    End Sub

    Private Sub ProgrammerCheckBox_CheckedChanged(sender As Object, e As EventArgs) Handles ProgrammerCheckBox.CheckedChanged
        ProgrammerLabel.Visible = ProgrammerCheckBox.Checked
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub
End Class
