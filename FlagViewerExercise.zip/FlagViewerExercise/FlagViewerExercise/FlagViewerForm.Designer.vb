﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FlagViewerForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.titleLabel = New System.Windows.Forms.Label()
        Me.ProgrammerLabel = New System.Windows.Forms.Label()
        Me.countryLabel = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.IndonesiaRadioButton = New System.Windows.Forms.RadioButton()
        Me.JapanRadioButton = New System.Windows.Forms.RadioButton()
        Me.UKRadioButton = New System.Windows.Forms.RadioButton()
        Me.MalaysiaRadioButton = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ProgrammerCheckBox = New System.Windows.Forms.CheckBox()
        Me.CountryCheckBox = New System.Windows.Forms.CheckBox()
        Me.TitleCheckBox = New System.Windows.Forms.CheckBox()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.IndonesiaPictureBox = New System.Windows.Forms.PictureBox()
        Me.JapanPictureBox = New System.Windows.Forms.PictureBox()
        Me.UKPictureBox = New System.Windows.Forms.PictureBox()
        Me.MalaysiaPictureBox = New System.Windows.Forms.PictureBox()
        Me.flagPictureBox = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.IndonesiaPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.JapanPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UKPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MalaysiaPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.flagPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'titleLabel
        '
        Me.titleLabel.AutoSize = True
        Me.titleLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.titleLabel.Location = New System.Drawing.Point(404, 26)
        Me.titleLabel.Name = "titleLabel"
        Me.titleLabel.Size = New System.Drawing.Size(197, 37)
        Me.titleLabel.TabIndex = 0
        Me.titleLabel.Text = "Flag Viewer"
        '
        'ProgrammerLabel
        '
        Me.ProgrammerLabel.AutoSize = True
        Me.ProgrammerLabel.Location = New System.Drawing.Point(45, 576)
        Me.ProgrammerLabel.Name = "ProgrammerLabel"
        Me.ProgrammerLabel.Size = New System.Drawing.Size(189, 20)
        Me.ProgrammerLabel.TabIndex = 0
        Me.ProgrammerLabel.Text = "Khan Muhammad Ahmad"
        '
        'countryLabel
        '
        Me.countryLabel.AutoSize = True
        Me.countryLabel.Location = New System.Drawing.Point(544, 336)
        Me.countryLabel.Name = "countryLabel"
        Me.countryLabel.Size = New System.Drawing.Size(70, 20)
        Me.countryLabel.TabIndex = 0
        Me.countryLabel.Text = "&Malaysia"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.IndonesiaRadioButton)
        Me.GroupBox1.Controls.Add(Me.JapanRadioButton)
        Me.GroupBox1.Controls.Add(Me.UKRadioButton)
        Me.GroupBox1.Controls.Add(Me.MalaysiaRadioButton)
        Me.GroupBox1.Location = New System.Drawing.Point(49, 73)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(330, 232)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Country"
        '
        'IndonesiaRadioButton
        '
        Me.IndonesiaRadioButton.AutoSize = True
        Me.IndonesiaRadioButton.Location = New System.Drawing.Point(18, 189)
        Me.IndonesiaRadioButton.Name = "IndonesiaRadioButton"
        Me.IndonesiaRadioButton.Size = New System.Drawing.Size(104, 24)
        Me.IndonesiaRadioButton.TabIndex = 0
        Me.IndonesiaRadioButton.Text = "&Indonesia"
        Me.IndonesiaRadioButton.UseVisualStyleBackColor = True
        '
        'JapanRadioButton
        '
        Me.JapanRadioButton.AutoSize = True
        Me.JapanRadioButton.Location = New System.Drawing.Point(15, 149)
        Me.JapanRadioButton.Name = "JapanRadioButton"
        Me.JapanRadioButton.Size = New System.Drawing.Size(78, 24)
        Me.JapanRadioButton.TabIndex = 0
        Me.JapanRadioButton.Text = "&Japan"
        Me.JapanRadioButton.UseVisualStyleBackColor = True
        '
        'UKRadioButton
        '
        Me.UKRadioButton.AutoSize = True
        Me.UKRadioButton.Location = New System.Drawing.Point(15, 102)
        Me.UKRadioButton.Name = "UKRadioButton"
        Me.UKRadioButton.Size = New System.Drawing.Size(147, 24)
        Me.UKRadioButton.TabIndex = 0
        Me.UKRadioButton.Text = "&United Kingdom"
        Me.UKRadioButton.UseVisualStyleBackColor = True
        '
        'MalaysiaRadioButton
        '
        Me.MalaysiaRadioButton.AutoSize = True
        Me.MalaysiaRadioButton.Checked = True
        Me.MalaysiaRadioButton.Location = New System.Drawing.Point(15, 46)
        Me.MalaysiaRadioButton.Name = "MalaysiaRadioButton"
        Me.MalaysiaRadioButton.Size = New System.Drawing.Size(95, 24)
        Me.MalaysiaRadioButton.TabIndex = 0
        Me.MalaysiaRadioButton.TabStop = True
        Me.MalaysiaRadioButton.Text = "&Malaysia"
        Me.MalaysiaRadioButton.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.ProgrammerCheckBox)
        Me.GroupBox2.Controls.Add(Me.CountryCheckBox)
        Me.GroupBox2.Controls.Add(Me.TitleCheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(49, 348)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(330, 189)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Display"
        '
        'ProgrammerCheckBox
        '
        Me.ProgrammerCheckBox.AutoSize = True
        Me.ProgrammerCheckBox.Checked = True
        Me.ProgrammerCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ProgrammerCheckBox.Location = New System.Drawing.Point(15, 138)
        Me.ProgrammerCheckBox.Name = "ProgrammerCheckBox"
        Me.ProgrammerCheckBox.Size = New System.Drawing.Size(122, 24)
        Me.ProgrammerCheckBox.TabIndex = 2
        Me.ProgrammerCheckBox.Text = "&Programmer"
        Me.ProgrammerCheckBox.UseVisualStyleBackColor = True
        '
        'CountryCheckBox
        '
        Me.CountryCheckBox.AutoSize = True
        Me.CountryCheckBox.Checked = True
        Me.CountryCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CountryCheckBox.Location = New System.Drawing.Point(15, 88)
        Me.CountryCheckBox.Name = "CountryCheckBox"
        Me.CountryCheckBox.Size = New System.Drawing.Size(136, 24)
        Me.CountryCheckBox.TabIndex = 1
        Me.CountryCheckBox.Text = "&Country Name"
        Me.CountryCheckBox.UseVisualStyleBackColor = True
        '
        'TitleCheckBox
        '
        Me.TitleCheckBox.AutoSize = True
        Me.TitleCheckBox.Checked = True
        Me.TitleCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TitleCheckBox.Location = New System.Drawing.Point(15, 46)
        Me.TitleCheckBox.Name = "TitleCheckBox"
        Me.TitleCheckBox.Size = New System.Drawing.Size(64, 24)
        Me.TitleCheckBox.TabIndex = 0
        Me.TitleCheckBox.Text = "&Title"
        Me.TitleCheckBox.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(520, 394)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(94, 36)
        Me.ExitButton.TabIndex = 3
        Me.ExitButton.Text = "E&xit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'IndonesiaPictureBox
        '
        Me.IndonesiaPictureBox.Image = Global.FlagViewerExercise.My.Resources.Resources.Indonesia_Flag
        Me.IndonesiaPictureBox.Location = New System.Drawing.Point(789, 563)
        Me.IndonesiaPictureBox.Name = "IndonesiaPictureBox"
        Me.IndonesiaPictureBox.Size = New System.Drawing.Size(117, 63)
        Me.IndonesiaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.IndonesiaPictureBox.TabIndex = 4
        Me.IndonesiaPictureBox.TabStop = False
        '
        'JapanPictureBox
        '
        Me.JapanPictureBox.Image = Global.FlagViewerExercise.My.Resources.Resources.Japan_Flag
        Me.JapanPictureBox.Location = New System.Drawing.Point(656, 563)
        Me.JapanPictureBox.Name = "JapanPictureBox"
        Me.JapanPictureBox.Size = New System.Drawing.Size(117, 63)
        Me.JapanPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.JapanPictureBox.TabIndex = 4
        Me.JapanPictureBox.TabStop = False
        '
        'UKPictureBox
        '
        Me.UKPictureBox.Image = Global.FlagViewerExercise.My.Resources.Resources.UK_Flag
        Me.UKPictureBox.Location = New System.Drawing.Point(533, 563)
        Me.UKPictureBox.Name = "UKPictureBox"
        Me.UKPictureBox.Size = New System.Drawing.Size(117, 63)
        Me.UKPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.UKPictureBox.TabIndex = 4
        Me.UKPictureBox.TabStop = False
        '
        'MalaysiaPictureBox
        '
        Me.MalaysiaPictureBox.Image = Global.FlagViewerExercise.My.Resources.Resources.Malaysia_Flag
        Me.MalaysiaPictureBox.Location = New System.Drawing.Point(406, 563)
        Me.MalaysiaPictureBox.Name = "MalaysiaPictureBox"
        Me.MalaysiaPictureBox.Size = New System.Drawing.Size(117, 63)
        Me.MalaysiaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.MalaysiaPictureBox.TabIndex = 4
        Me.MalaysiaPictureBox.TabStop = False
        '
        'flagPictureBox
        '
        Me.flagPictureBox.Image = Global.FlagViewerExercise.My.Resources.Resources.Malaysia_Flag
        Me.flagPictureBox.Location = New System.Drawing.Point(406, 83)
        Me.flagPictureBox.Name = "flagPictureBox"
        Me.flagPictureBox.Size = New System.Drawing.Size(484, 222)
        Me.flagPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.flagPictureBox.TabIndex = 2
        Me.flagPictureBox.TabStop = False
        '
        'FlagViewerForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(918, 638)
        Me.Controls.Add(Me.IndonesiaPictureBox)
        Me.Controls.Add(Me.JapanPictureBox)
        Me.Controls.Add(Me.UKPictureBox)
        Me.Controls.Add(Me.MalaysiaPictureBox)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.flagPictureBox)
        Me.Controls.Add(Me.ProgrammerLabel)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.countryLabel)
        Me.Controls.Add(Me.titleLabel)
        Me.Name = "FlagViewerForm"
        Me.Text = "Flag Viewer Application"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.IndonesiaPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.JapanPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UKPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MalaysiaPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.flagPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents titleLabel As Label
    Friend WithEvents ProgrammerLabel As Label
    Friend WithEvents countryLabel As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents IndonesiaRadioButton As RadioButton
    Friend WithEvents JapanRadioButton As RadioButton
    Friend WithEvents UKRadioButton As RadioButton
    Friend WithEvents MalaysiaRadioButton As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents ProgrammerCheckBox As CheckBox
    Friend WithEvents CountryCheckBox As CheckBox
    Friend WithEvents TitleCheckBox As CheckBox
    Friend WithEvents flagPictureBox As PictureBox
    Friend WithEvents ExitButton As Button
    Friend WithEvents MalaysiaPictureBox As PictureBox
    Friend WithEvents UKPictureBox As PictureBox
    Friend WithEvents JapanPictureBox As PictureBox
    Friend WithEvents IndonesiaPictureBox As PictureBox
End Class
